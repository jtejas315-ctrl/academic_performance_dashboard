# Academic Performance Dashboard (Hardened Edition)

## Quick Start
```bash
python3 academic_dashboard.py
```
Optional plotting support:
```bash
pip install -r requirements.txt
```

## Project Structure
- `academic_dashboard.py` — Complete application with security walls, statistical analytics, atomic persistence, and CLI.
- `data/sample_import.csv` — Sample CSV file (including an intentional invalid row) to test bulk import validation.
- `requirements.txt` — Optional `matplotlib` dependency (falls back gracefully to ASCII charts if absent).
